================================================================
 LOSOWNIK.PL — HOTFIX i18n / icon-nav — README (v2)
================================================================
Cel: ujednolicić mechanizm języków i przywrócić spójność UI, BEZ zmiany
layoutu v3 produkcji. To hotfix, nie redesign. Produkcja NIE została ruszona.

ZMIANA WZGLĘDEM v1 PACZKI:
  Listing FTP potwierdził, że katalogi narzędzi (kostka/, lotto/, ...) ISTNIEJĄ
  w /public_html/losownik2/. Reguły pretty-URL w .htaccess serwują
  <tool>/index.html, gdy katalog istnieje. Dlatego dla każdego polskiego
  narzędzia paczka v2 zawiera OBA warianty z identyczną treścią:
    - plik płaski      <tool>.html
    - plik katalogowy  <tool>/index.html
  Katalogów NIE usuwamy. .htaccess NIE zmieniamy.

----------------------------------------------------------------
CO ZOSTAŁO ZMIENIONE (treść v3, oba warianty PL)
----------------------------------------------------------------
STRONY PL (index.html + 13 narzędzi):
  - Usunięto inline'owy stary i18n (przełącznik wstrzykiwany JS: ?lang,
    localStorage, location.reload, tłumaczenie JS + blok window.LOSOWNIK_T).
  - Dodano STATYCZNY przełącznik <select class="lang-select"> -> fizyczne URL-e.
    "Polski" = canonical bez trailing slash (np. /kostka).
  - Dodano CSS .lang-select (ten sam ciemny/fioletowy wygląd co dawny JS).
  - Dodano statyczny komplet hreflang (pl,en,de,es,fr,it,pt,ru,cs,uk,x-default)
    + zachowano istniejący canonical.
  - icon-nav v3 (15 pozycji, Z RULETKĄ), layout, kolory, fonty oraz mechanika
    i dźwięki (/js/sounds.js + inline) — NIETKNIĘTE (zweryfikowane).

WERSJE JĘZYKOWE (en/ ... uk/, po 14):
  - top-nav (tekst) -> icon-nav (14 pozycji, BEZ Ruletki — brak /xx/ruletka).
  - Dodano CSS .icon-nav + .lang-select i skrypt drag-scroll.
  - Istniejący statyczny przełącznik i hreflang — zostawione.

SERVICE WORKER:
  - sw.js: CACHE_NAME 'losownik-v2' -> 'losownik-v3'. Logika i precache bez zmian.

----------------------------------------------------------------
KONTROLA REGRESJI (wykonana)
----------------------------------------------------------------
  - sounds.js ładowany jak wcześniej; liczba wywołań dźwięku bez zmian.
  - Z każdej strony PL usunięto wyłącznie 2 bloki i18n; inline-mechanika
    (kostka/moneta/karty/lotto itd.) i eventy przycisków — nienaruszone.
  - Wersje językowe: żadnego skryptu nie usunięto (dodano tylko drag-scroll).
  - ruletka.html, ruletka/index.html, ruletka-wariant-*.html — bajt-w-bajt jak
    produkcja (NIE w paczce, NIE zmieniane).

----------------------------------------------------------------
ABSOLUTNIE NIE RUSZAĆ
----------------------------------------------------------------
  ruletka.html, ruletka/index.html, ruletka-wariant-*.html
  .htaccess, sitemap.xml, robots.txt, manifest.json, css/, js/
  ŻADNYCH katalogów NIE USUWAĆ.

----------------------------------------------------------------
SZYBKI TEST PO WDROŻENIU
----------------------------------------------------------------
  /           -> icon-nav (15, z Ruletką), przełącznik ostylowany, English->/en/, brak ?lang
  /kostka     -> jw., English->/en/kostka, brak starego i18n w źródle
  /en/        -> icon-nav (14), przełącznik w tym samym stylu, Polski->/
  /en/kostka  -> icon-nav (14), Polski->/kostka
  Cache: odśwież Ctrl/Cmd+Shift+R; SW podbity do v3 wyczyści stary.
  Sprawdź dodatkowo, że /kostka i (jeśli serwowane) /kostka/ dają tę samą,
  nową wersję — oba pliki są identyczne, więc powinny.
