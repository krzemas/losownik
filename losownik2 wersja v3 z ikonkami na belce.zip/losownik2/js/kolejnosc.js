(function() {
    var itemsEl = document.getElementById('order-items');
    var resultEl = document.getElementById('order-result');
    var shuffleBtn = document.getElementById('shuffle-btn');

    function secureRandom(max) {
        var array = new Uint32Array(1);
        crypto.getRandomValues(array);
        return array[0] % max;
    }

    function shuffle(arr) {
        var shuffled = arr.slice();
        for (var i = shuffled.length - 1; i > 0; i--) {
            var j = secureRandom(i + 1);
            var temp = shuffled[i];
            shuffled[i] = shuffled[j];
            shuffled[j] = temp;
        }
        return shuffled;
    }

    function doShuffle() {
        var items = itemsEl.value.split('\n').map(function(s) { return s.trim(); }).filter(function(s) { return s.length > 0; });

        if (items.length < 2) {
            resultEl.innerHTML = '<li style="color:#e74c3c;">Wpisz co najmniej 2 elementy!</li>';
            return;
        }

        var shuffled = shuffle(items);
        var html = '';
        for (var i = 0; i < shuffled.length; i++) {
            html += '<li>' + shuffled[i] + '</li>';
        }
        resultEl.innerHTML = html;
    }

    shuffleBtn.addEventListener('click', doShuffle);
})();
