(function() {
    var namesEl = document.getElementById('team-names');
    var countEl = document.getElementById('team-count');
    var resultEl = document.getElementById('teams-result');
    var divideBtn = document.getElementById('divide-btn');

    function secureRandom(max) {
        var array = new Uint32Array(1);
        crypto.getRandomValues(array);
        return array[0] % max;
    }

    function shuffle(arr) {
        var shuffled = arr.slice();
        for (var i = shuffled.length - 1; i > 0; i--) {
            var j = secureRandom(i + 1);
            var temp = shuffled[i];
            shuffled[i] = shuffled[j];
            shuffled[j] = temp;
        }
        return shuffled;
    }

    function divide() {
        var names = namesEl.value.split('\n').map(function(s) { return s.trim(); }).filter(function(s) { return s.length > 0; });
        var teamCount = parseInt(countEl.value);

        if (names.length < teamCount) {
            resultEl.innerHTML = '<p style="color:#e74c3c;">Potrzebujesz co najmniej tyle graczy, ile drużyn!</p>';
            return;
        }

        var shuffled = shuffle(names);
        var teams = [];
        for (var i = 0; i < teamCount; i++) {
            teams.push([]);
        }

        for (var i = 0; i < shuffled.length; i++) {
            teams[i % teamCount].push(shuffled[i]);
        }

        var html = '';
        for (var i = 0; i < teams.length; i++) {
            html += '<div style="margin-bottom:1rem;padding:1rem;background:var(--bg-card,#f8f9fa);border-radius:8px;">';
            html += '<strong>Drużyna ' + (i + 1) + ':</strong> ';
            html += teams[i].join(', ');
            html += '</div>';
        }

        resultEl.innerHTML = html;
    }

    divideBtn.addEventListener('click', divide);
})();
