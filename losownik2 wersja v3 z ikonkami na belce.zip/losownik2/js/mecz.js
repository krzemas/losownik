(function() {
    var sport = 'football';
    var resultEl = document.getElementById('match-result');
    var generateBtn = document.getElementById('generate-btn');
    var tabs = document.querySelectorAll('.option-tabs button');

    function secureRandom(max) {
        var array = new Uint32Array(1);
        crypto.getRandomValues(array);
        return array[0] % max;
    }

    function secureRandomRange(min, max) {
        return min + secureRandom(max - min + 1);
    }

    function generateFootball() {
        var home = secureRandom(6);
        var away = secureRandom(6);
        return home + ' : ' + away;
    }

    function generateVolleyball() {
        var setsHome = 0;
        var setsAway = 0;
        var sets = [];
        while (setsHome < 3 && setsAway < 3) {
            var scoreA = 25;
            var scoreB = secureRandomRange(15, 25);
            if (secureRandom(2) === 0) {
                var temp = scoreA;
                scoreA = scoreB;
                scoreB = temp;
            }
            if (scoreA === scoreB) scoreA += 2;
            if (scoreA > scoreB) {
                setsHome++;
            } else {
                setsAway++;
            }
            sets.push(scoreA + ':' + scoreB);
        }
        return setsHome + ' : ' + setsAway + ' (' + sets.join(', ') + ')';
    }

    function generateHandball() {
        var home = secureRandomRange(20, 40);
        var away = secureRandomRange(20, 40);
        return home + ' : ' + away;
    }

    function generateBasketball() {
        var home = secureRandomRange(70, 130);
        var away = secureRandomRange(70, 130);
        return home + ' : ' + away;
    }

    function generate() {
        var result;
        switch (sport) {
            case 'football': result = generateFootball(); break;
            case 'volleyball': result = generateVolleyball(); break;
            case 'handball': result = generateHandball(); break;
            case 'basketball': result = generateBasketball(); break;
        }
        resultEl.textContent = result;
        resultEl.classList.remove('placeholder');
    }

    tabs.forEach(function(tab) {
        tab.addEventListener('click', function() {
            tabs.forEach(function(t) { t.classList.remove('active'); });
            tab.classList.add('active');
            sport = tab.dataset.sport;
            resultEl.textContent = 'Kliknij aby wylosować wynik';
            resultEl.classList.add('placeholder');
        });
    });

    generateBtn.addEventListener('click', generate);
    resultEl.addEventListener('click', generate);
    resultEl.style.cursor = 'pointer';
})();
