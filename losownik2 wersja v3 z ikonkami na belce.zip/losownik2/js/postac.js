(function() {
    var generateBtn = document.getElementById('generate-btn');
    var resultEl = document.getElementById('character-result');

    var races = ['Człowiek', 'Elf', 'Krasnolud', 'Niziołek', 'Półelf', 'Półork', 'Gnom', 'Dragonborn', 'Tiefling'];
    var classes = ['Wojownik', 'Mag', 'Łotr', 'Kleryk', 'Barbarzyńca', 'Bard', 'Druid', 'Mnich', 'Paladyn', 'Ranger', 'Czarnoksiężnik', 'Czarodziej'];
    var maleNames = ['Aldric', 'Borin', 'Cedric', 'Darian', 'Eldric', 'Fenris', 'Gareth', 'Haldor', 'Ivar', 'Jorin', 'Kael', 'Lorek', 'Maelon', 'Noric', 'Orin'];
    var femaleNames = ['Aelith', 'Brenna', 'Cyra', 'Dahlia', 'Elara', 'Freya', 'Gwendolyn', 'Helena', 'Iris', 'Jade', 'Kira', 'Luna', 'Mira', 'Nadia', 'Ophelia'];
    var traits = ['Odważny', 'Ostrożny', 'Honorowy', 'Sprytny', 'Lojalny', 'Samotnik', 'Charyzmatyczny', 'Tajemniczy', 'Impulsywny', 'Mądry', 'Uparty', 'Życzliwy'];

    function secureRandom(max) {
        var array = new Uint32Array(1);
        crypto.getRandomValues(array);
        return array[0] % max;
    }

    function rollStat() {
        var rolls = [];
        for (var i = 0; i < 4; i++) {
            rolls.push(secureRandom(6) + 1);
        }
        rolls.sort(function(a, b) { return a - b; });
        return rolls[1] + rolls[2] + rolls[3];
    }

    function generate() {
        var isMale = secureRandom(2) === 0;
        var name = isMale
            ? maleNames[secureRandom(maleNames.length)]
            : femaleNames[secureRandom(femaleNames.length)];
        var race = races[secureRandom(races.length)];
        var charClass = classes[secureRandom(classes.length)];
        var trait = traits[secureRandom(traits.length)];

        var stats = {
            STR: rollStat(),
            DEX: rollStat(),
            CON: rollStat(),
            INT: rollStat(),
            WIS: rollStat(),
            CHA: rollStat()
        };

        var html = '<div style="background:var(--bg-card,#f8f9fa);border-radius:12px;padding:1.5rem;">';
        html += '<h3 style="margin-top:0;">🏷️ ' + name + '</h3>';
        html += '<p><strong>Rasa:</strong> ' + race + '</p>';
        html += '<p><strong>Klasa:</strong> ' + charClass + '</p>';
        html += '<p><strong>Cecha:</strong> ' + trait + '</p>';
        html += '<h4>📊 Statystyki (4d6 drop lowest):</h4>';
        html += '<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:0.5rem;">';

        var statNames = ['STR', 'DEX', 'CON', 'INT', 'WIS', 'CHA'];
        var statLabels = ['Siła', 'Zręczność', 'Kondycja', 'Inteligencja', 'Mądrość', 'Charyzma'];
        for (var i = 0; i < statNames.length; i++) {
            var val = stats[statNames[i]];
            var mod = Math.floor((val - 10) / 2);
            var modStr = mod >= 0 ? '+' + mod : '' + mod;
            html += '<div style="text-align:center;padding:0.5rem;background:#fff;border-radius:8px;border:1px solid #e0e0e0;">';
            html += '<div style="font-size:0.75rem;color:#666;">' + statLabels[i] + '</div>';
            html += '<div style="font-size:1.3rem;font-weight:bold;">' + val + '</div>';
            html += '<div style="font-size:0.8rem;color:#888;">' + modStr + '</div>';
            html += '</div>';
        }

        html += '</div></div>';
        resultEl.innerHTML = html;
    }

    generateBtn.addEventListener('click', generate);
})();
