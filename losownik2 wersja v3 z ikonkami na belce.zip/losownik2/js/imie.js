(function() {
    var maleNames = [
        'Adam', 'Bartosz', 'Cezary', 'Dawid', 'Emil', 'Filip', 'Grzegorz',
        'Hubert', 'Igor', 'Jakub', 'Kamil', 'Łukasz', 'Marcin', 'Norbert',
        'Oskar', 'Piotr', 'Rafał', 'Sebastian', 'Tomasz', 'Wojciech',
        'Zbigniew', 'Artur', 'Dominik', 'Krzysztof', 'Maciej', 'Michał',
        'Paweł', 'Robert', 'Stanisław', 'Wiktor'
    ];

    var femaleNames = [
        'Anna', 'Barbara', 'Celina', 'Dorota', 'Ewa', 'Franciszka', 'Grażyna',
        'Halina', 'Izabela', 'Joanna', 'Katarzyna', 'Lucyna', 'Małgorzata',
        'Natalia', 'Oliwia', 'Paulina', 'Renata', 'Sylwia', 'Teresa', 'Urszula',
        'Weronika', 'Zofia', 'Agnieszka', 'Beata', 'Danuta', 'Elżbieta',
        'Justyna', 'Karolina', 'Magdalena', 'Monika'
    ];

    var surnames = [
        'Nowak', 'Kowalski', 'Wiśniewski', 'Wójcik', 'Kowalczyk', 'Kamiński',
        'Lewandowski', 'Zieliński', 'Szymański', 'Woźniak', 'Dąbrowski',
        'Kozłowski', 'Jankowski', 'Mazur', 'Kwiatkowski', 'Krawczyk',
        'Piotrowski', 'Grabowski', 'Nowakowski', 'Pawłowski', 'Michalski',
        'Adamczyk', 'Dudek', 'Zając', 'Wieczorek', 'Jabłoński', 'Król',
        'Majewski', 'Olszewski', 'Stępień'
    ];

    var type = 'male';
    var resultEl = document.getElementById('name-result');
    var generateBtn = document.getElementById('generate-btn');
    var tabs = document.querySelectorAll('.option-tabs button');

    function secureRandom(max) {
        var array = new Uint32Array(1);
        crypto.getRandomValues(array);
        return array[0] % max;
    }

    function feminizeSurname(surname) {
        if (surname.endsWith('ski')) return surname.slice(0, -1) + 'a';
        if (surname.endsWith('cki')) return surname.slice(0, -1) + 'a';
        if (surname.endsWith('dzki')) return surname.slice(0, -1) + 'a';
        return surname;
    }

    function generate() {
        var result;
        if (type === 'male') {
            result = maleNames[secureRandom(maleNames.length)];
        } else if (type === 'female') {
            result = femaleNames[secureRandom(femaleNames.length)];
        } else {
            var isMale = secureRandom(2) === 0;
            var firstName = isMale
                ? maleNames[secureRandom(maleNames.length)]
                : femaleNames[secureRandom(femaleNames.length)];
            var surname = surnames[secureRandom(surnames.length)];
            if (!isMale) surname = feminizeSurname(surname);
            result = firstName + ' ' + surname;
        }
        resultEl.textContent = result;
        resultEl.classList.remove('placeholder');
    }

    tabs.forEach(function(tab) {
        tab.addEventListener('click', function() {
            tabs.forEach(function(t) { t.classList.remove('active'); });
            tab.classList.add('active');
            type = tab.dataset.type;
            resultEl.textContent = 'Kliknij aby wylosować';
            resultEl.classList.add('placeholder');
        });
    });

    generateBtn.addEventListener('click', generate);
    resultEl.addEventListener('click', generate);
    resultEl.style.cursor = 'pointer';
})();
