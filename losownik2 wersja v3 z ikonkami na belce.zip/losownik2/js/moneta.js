// Coin flip logic
(function() {
    let heads = 0, tails = 0;
    const resultEl = document.getElementById('coin-result');
    const flipBtn = document.getElementById('flip-btn');
    const headsEl = document.getElementById('heads-count');
    const tailsEl = document.getElementById('tails-count');
    const totalEl = document.getElementById('total-count');

    function flip() {
        const array = new Uint32Array(1);
        crypto.getRandomValues(array);
        const isHeads = array[0] % 2 === 0;

        if (isHeads) {
            heads++;
            resultEl.textContent = '🦅 ORZEŁ';
        } else {
            tails++;
            resultEl.textContent = '🪙 RESZKA';
        }
        resultEl.classList.remove('placeholder');
        headsEl.textContent = heads;
        tailsEl.textContent = tails;
        totalEl.textContent = heads + tails;
    }

    flipBtn.addEventListener('click', flip);
    resultEl.addEventListener('click', flip);
    resultEl.style.cursor = 'pointer';
})();
