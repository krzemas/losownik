(function() {
    var redNumbers = [1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36];
    var balance = 1000;
    var betAmount = 10;
    var history = [];

    var balanceEl = document.getElementById('balance');
    var betTypeEl = document.getElementById('bet-type');
    var betNumberEl = document.getElementById('bet-number');
    var resultEl = document.getElementById('roulette-result');
    var spinBtn = document.getElementById('spin-btn');
    var historyEl = document.getElementById('history-list');
    var betAmountBtns = document.querySelectorAll('.bet-amount');

    function secureRandom(max) {
        var array = new Uint32Array(1);
        crypto.getRandomValues(array);
        return array[0] % max;
    }

    function isRed(n) {
        return redNumbers.indexOf(n) !== -1;
    }

    function getColor(n) {
        if (n === 0) return 'green';
        return isRed(n) ? 'red' : 'black';
    }

    function getColorEmoji(n) {
        if (n === 0) return '🟢';
        return isRed(n) ? '🔴' : '⚫';
    }

    function checkWin(number) {
        var type = betTypeEl.value;
        if (number === 0) {
            if (type === 'number' && parseInt(betNumberEl.value) === 0) return 35;
            return -1;
        }
        switch (type) {
            case 'red': return isRed(number) ? 1 : -1;
            case 'black': return !isRed(number) ? 1 : -1;
            case 'even': return (number % 2 === 0) ? 1 : -1;
            case 'odd': return (number % 2 === 1) ? 1 : -1;
            case 'low': return (number >= 1 && number <= 18) ? 1 : -1;
            case 'high': return (number >= 19 && number <= 36) ? 1 : -1;
            case 'number': return (number === parseInt(betNumberEl.value)) ? 35 : -1;
            default: return -1;
        }
    }

    function spin() {
        if (balance < betAmount) {
            resultEl.textContent = 'Brak żetonów! Odśwież stronę, aby zacząć od nowa.';
            resultEl.classList.remove('placeholder');
            return;
        }

        var number = secureRandom(37);
        var multiplier = checkWin(number);
        var winnings = betAmount * multiplier;
        balance += winnings;

        var colorEmoji = getColorEmoji(number);
        var resultText = colorEmoji + ' ' + number;

        if (multiplier > 0) {
            resultText += ' – Wygrana! +' + (betAmount * multiplier) + ' żetonów';
        } else {
            resultText += ' – Przegrana: -' + betAmount + ' żetonów';
        }

        resultEl.textContent = resultText;
        resultEl.classList.remove('placeholder');
        balanceEl.textContent = balance;

        history.unshift(colorEmoji + number);
        if (history.length > 10) history.pop();
        historyEl.textContent = history.join(' | ');
    }

    betTypeEl.addEventListener('change', function() {
        betNumberEl.style.display = betTypeEl.value === 'number' ? 'inline-block' : 'none';
    });

    betAmountBtns.forEach(function(btn) {
        btn.addEventListener('click', function() {
            betAmountBtns.forEach(function(b) { b.classList.remove('active'); });
            btn.classList.add('active');
            betAmount = parseInt(btn.dataset.amount);
        });
    });

    spinBtn.addEventListener('click', spin);
})();
