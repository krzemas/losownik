(function() {
    var listEl = document.getElementById('people-list');
    var resultEl = document.getElementById('winner-result');
    var pickBtn = document.getElementById('pick-btn');

    function secureRandom(max) {
        var array = new Uint32Array(1);
        crypto.getRandomValues(array);
        return array[0] % max;
    }

    function pick() {
        var people = listEl.value.split('\n').map(function(s) { return s.trim(); }).filter(function(s) { return s.length > 0; });

        if (people.length < 2) {
            resultEl.textContent = 'Wpisz co najmniej 2 osoby!';
            resultEl.classList.remove('placeholder');
            return;
        }

        var winner = people[secureRandom(people.length)];
        resultEl.textContent = '🎉 ' + winner + '!';
        resultEl.classList.remove('placeholder');
    }

    pickBtn.addEventListener('click', pick);
})();
