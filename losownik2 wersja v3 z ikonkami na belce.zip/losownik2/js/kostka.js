// Dice roller logic
(function() {
    let sides = 6;
    const history = [];
    const resultEl = document.getElementById('dice-result');
    const historyEl = document.getElementById('history-list');
    const rollBtn = document.getElementById('roll-btn');
    const tabs = document.querySelectorAll('.option-tabs button');

    function secureRandom(max) {
        const array = new Uint32Array(1);
        crypto.getRandomValues(array);
        return (array[0] % max) + 1;
    }

    function roll() {
        const result = secureRandom(sides);
        resultEl.textContent = result;
        resultEl.classList.remove('placeholder');
        history.unshift(result);
        if (history.length > 20) history.pop();
        historyEl.textContent = history.join(', ');
    }

    tabs.forEach(function(tab) {
        tab.addEventListener('click', function() {
            tabs.forEach(function(t) { t.classList.remove('active'); });
            tab.classList.add('active');
            sides = parseInt(tab.dataset.sides);
            resultEl.textContent = 'Kliknij aby rzucić k' + sides;
            resultEl.classList.add('placeholder');
        });
    });

    rollBtn.addEventListener('click', roll);
    resultEl.addEventListener('click', roll);
    resultEl.style.cursor = 'pointer';
})();
