(function() {
    var canvas = document.getElementById('wheel-canvas');
    var ctx = canvas.getContext('2d');
    var optionsEl = document.getElementById('wheel-options');
    var resultEl = document.getElementById('wheel-result');
    var spinBtn = document.getElementById('spin-btn');
    var spinning = false;
    var currentAngle = 0;

    var colors = [
        '#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF',
        '#FF9F40', '#E7E9ED', '#7BC8A4', '#F67280', '#6C5B7B',
        '#C06C84', '#355C7D', '#F8B500', '#2ECC71', '#E74C3C'
    ];

    function secureRandom(max) {
        var array = new Uint32Array(1);
        crypto.getRandomValues(array);
        return array[0] % max;
    }

    function getOptions() {
        return optionsEl.value.split('\n').map(function(s) { return s.trim(); }).filter(function(s) { return s.length > 0; });
    }

    function drawWheel(options, angle) {
        var cx = canvas.width / 2;
        var cy = canvas.height / 2;
        var radius = Math.min(cx, cy) - 10;
        var sliceAngle = (2 * Math.PI) / options.length;

        ctx.clearRect(0, 0, canvas.width, canvas.height);

        for (var i = 0; i < options.length; i++) {
            var startAngle = angle + i * sliceAngle;
            var endAngle = startAngle + sliceAngle;

            ctx.beginPath();
            ctx.moveTo(cx, cy);
            ctx.arc(cx, cy, radius, startAngle, endAngle);
            ctx.closePath();
            ctx.fillStyle = colors[i % colors.length];
            ctx.fill();
            ctx.strokeStyle = '#fff';
            ctx.lineWidth = 2;
            ctx.stroke();

            ctx.save();
            ctx.translate(cx, cy);
            ctx.rotate(startAngle + sliceAngle / 2);
            ctx.textAlign = 'right';
            ctx.fillStyle = '#fff';
            ctx.font = 'bold 14px sans-serif';
            ctx.shadowColor = 'rgba(0,0,0,0.5)';
            ctx.shadowBlur = 3;
            var label = options[i].length > 15 ? options[i].substring(0, 13) + '…' : options[i];
            ctx.fillText(label, radius - 15, 5);
            ctx.restore();
        }

        // Draw pointer
        ctx.beginPath();
        ctx.moveTo(cx + radius + 5, cy);
        ctx.lineTo(cx + radius + 20, cy - 10);
        ctx.lineTo(cx + radius + 20, cy + 10);
        ctx.closePath();
        ctx.fillStyle = '#333';
        ctx.fill();
    }

    function spin() {
        var options = getOptions();
        if (options.length < 2) {
            resultEl.textContent = 'Wpisz co najmniej 2 opcje!';
            resultEl.classList.remove('placeholder');
            return;
        }
        if (spinning) return;
        spinning = true;

        var winnerIndex = secureRandom(options.length);
        var sliceAngle = (2 * Math.PI) / options.length;
        var targetAngle = (2 * Math.PI) * (5 + secureRandom(5)) - (winnerIndex * sliceAngle + sliceAngle / 2);

        var startTime = null;
        var duration = 3000 + secureRandom(2000);
        var startAngle = currentAngle;

        function animate(timestamp) {
            if (!startTime) startTime = timestamp;
            var progress = Math.min((timestamp - startTime) / duration, 1);
            var eased = 1 - Math.pow(1 - progress, 4);
            currentAngle = startAngle + targetAngle * eased;
            drawWheel(options, currentAngle);

            if (progress < 1) {
                requestAnimationFrame(animate);
            } else {
                spinning = false;
                resultEl.textContent = '🎉 ' + options[winnerIndex];
                resultEl.classList.remove('placeholder');
            }
        }

        requestAnimationFrame(animate);
    }

    function init() {
        var options = getOptions();
        if (options.length >= 2) {
            drawWheel(options, currentAngle);
        } else {
            drawWheel(['Opcja 1', 'Opcja 2', 'Opcja 3'], currentAngle);
        }
    }

    spinBtn.addEventListener('click', spin);
    optionsEl.addEventListener('input', function() {
        var options = getOptions();
        if (options.length >= 2) drawWheel(options, currentAngle);
    });

    init();
})();
