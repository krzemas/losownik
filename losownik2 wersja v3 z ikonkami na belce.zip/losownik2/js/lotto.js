// Lotto generator logic
(function() {
    const games = {
        lotto: { count: 6, max: 49, sorted: true },
        mini: { count: 5, max: 42, sorted: true },
        multi: { count: 20, max: 80, sorted: true },
        joker: { count: 6, max: 9, sorted: false, digits: true }
    };

    let currentGame = 'lotto';
    const resultEl = document.getElementById('lotto-result');
    const lottoBtn = document.getElementById('lotto-btn');
    const tabs = document.querySelectorAll('.option-tabs button');

    function secureRandomRange(min, max) {
        const array = new Uint32Array(1);
        crypto.getRandomValues(array);
        return min + (array[0] % (max - min + 1));
    }

    function generateNumbers() {
        const game = games[currentGame];

        if (game.digits) {
            // Joker: 6 random digits 0-9
            const digits = [];
            for (let i = 0; i < game.count; i++) {
                digits.push(secureRandomRange(0, game.max));
            }
            resultEl.textContent = digits.join(' ');
        } else {
            // Standard: unique numbers
            const numbers = new Set();
            while (numbers.size < game.count) {
                numbers.add(secureRandomRange(1, game.max));
            }
            let result = Array.from(numbers);
            if (game.sorted) result.sort(function(a, b) { return a - b; });
            resultEl.textContent = result.join('  ');
        }
        resultEl.classList.remove('placeholder');
    }

    tabs.forEach(function(tab) {
        tab.addEventListener('click', function() {
            tabs.forEach(function(t) { t.classList.remove('active'); });
            tab.classList.add('active');
            currentGame = tab.dataset.game;
            resultEl.textContent = 'Kliknij przycisk aby wylosować';
            resultEl.classList.add('placeholder');
        });
    });

    lottoBtn.addEventListener('click', generateNumbers);
})();
