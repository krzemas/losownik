(function() {
    var colorBox = document.getElementById('color-box');
    var hexEl = document.getElementById('color-hex');
    var rgbEl = document.getElementById('color-rgb');
    var generateBtn = document.getElementById('generate-btn');

    function secureRandomByte() {
        var array = new Uint8Array(1);
        crypto.getRandomValues(array);
        return array[0];
    }

    function toHex(n) {
        var hex = n.toString(16).toUpperCase();
        return hex.length === 1 ? '0' + hex : hex;
    }

    function generate() {
        var r = secureRandomByte();
        var g = secureRandomByte();
        var b = secureRandomByte();

        var hex = '#' + toHex(r) + toHex(g) + toHex(b);
        var rgb = 'rgb(' + r + ', ' + g + ', ' + b + ')';

        colorBox.style.background = hex;
        hexEl.textContent = hex;
        hexEl.classList.remove('placeholder');
        rgbEl.textContent = rgb;
    }

    generateBtn.addEventListener('click', generate);
    colorBox.addEventListener('click', generate);
    colorBox.style.cursor = 'pointer';
})();
