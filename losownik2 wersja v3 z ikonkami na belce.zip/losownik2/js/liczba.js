(function() {
    var minEl = document.getElementById('num-min');
    var maxEl = document.getElementById('num-max');
    var qtyEl = document.getElementById('num-qty');
    var resultEl = document.getElementById('number-result');
    var generateBtn = document.getElementById('generate-btn');

    function secureRandom(max) {
        var array = new Uint32Array(1);
        crypto.getRandomValues(array);
        return array[0] % max;
    }

    function generate() {
        var min = parseInt(minEl.value);
        var max = parseInt(maxEl.value);
        var qty = parseInt(qtyEl.value);

        if (isNaN(min) || isNaN(max) || isNaN(qty)) {
            resultEl.textContent = 'Uzupełnij wszystkie pola!';
            resultEl.classList.remove('placeholder');
            return;
        }

        if (min >= max) {
            resultEl.textContent = 'Minimum musi być mniejsze od maksimum!';
            resultEl.classList.remove('placeholder');
            return;
        }

        if (qty < 1) qty = 1;
        if (qty > 100) qty = 100;

        var range = max - min + 1;
        var results = [];
        for (var i = 0; i < qty; i++) {
            results.push(min + secureRandom(range));
        }

        resultEl.textContent = results.join(', ');
        resultEl.classList.remove('placeholder');
    }

    generateBtn.addEventListener('click', generate);
    resultEl.addEventListener('click', generate);
    resultEl.style.cursor = 'pointer';
})();
