(function() {
    var values = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'Walet', 'Dama', 'Król', 'As'];
    var suits = [
        { name: 'pik', emoji: '♠' },
        { name: 'kier', emoji: '♥' },
        { name: 'karo', emoji: '♦' },
        { name: 'trefl', emoji: '♣' }
    ];

    var resultEl = document.getElementById('card-result');
    var drawBtn = document.getElementById('draw-btn');
    var historyEl = document.getElementById('history-list');
    var history = [];

    function secureRandom(max) {
        var array = new Uint32Array(1);
        crypto.getRandomValues(array);
        return array[0] % max;
    }

    function draw() {
        var value = values[secureRandom(values.length)];
        var suit = suits[secureRandom(suits.length)];
        var isRed = suit.name === 'kier' || suit.name === 'karo';

        var cardText = value + ' ' + suit.emoji;
        resultEl.textContent = cardText;
        resultEl.classList.remove('placeholder');
        resultEl.style.color = isRed ? '#e74c3c' : '#2c3e50';

        history.unshift(cardText);
        if (history.length > 10) history.pop();
        historyEl.textContent = history.join(' | ');
    }

    drawBtn.addEventListener('click', draw);
    resultEl.addEventListener('click', draw);
    resultEl.style.cursor = 'pointer';
})();
