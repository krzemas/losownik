﻿// Mobile navigation toggle
document.addEventListener('DOMContentLoaded', function() {
    const toggle = document.querySelector('.nav-toggle');
    const nav = document.querySelector('.main-nav');

    if (toggle && nav) {
        toggle.addEventListener('click', function() {
            const isOpen = nav.classList.toggle('open');
            toggle.setAttribute('aria-expanded', isOpen);
        });

        // Close menu on link click (mobile)
        nav.querySelectorAll('a').forEach(function(link) {
            link.addEventListener('click', function() {
                nav.classList.remove('open');
                toggle.setAttribute('aria-expanded', 'false');
            });
        });
    }

    // Mark active nav item
    const currentPath = window.location.pathname.replace(/\/$/, '') || '/';
    document.querySelectorAll('.main-nav a').forEach(function(link) {
        const href = link.getAttribute('href').replace(/\/$/, '') || '/';
        if (href === currentPath) {
            link.classList.add('active');
        }
    });
});

// Register Service Worker
if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('/sw.js').catch(function() {});
}
